<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="tileset" tilewidth="8" tileheight="8" tilecount="24" columns="6">
 <image source="tileset.png" width="48" height="32"/>
</tileset>
