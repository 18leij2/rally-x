#ifndef TILEMAP_H
#define TILEMAP_H

#define TILEMAP_WIDTH  (64)
#define TILEMAP_HEIGHT (64)
#define tilemapMapLen (8192)

extern const unsigned short tilemapMap[4096];

#endif
